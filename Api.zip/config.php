<?php
$db = [
    'host' => 'localhost',
    'username' => 'usrapiplaza',
    'password' => 'zCjbTTe2yZyHwAAl',
    'db' => 'dbplaza'
];
define('API_KEY','3d524a53c110e4c22463b10ed3254as');
?>
