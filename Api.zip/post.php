<?php
include "config.php";
include "utils.php";


$dbConn =  connect($db);

/*
  listar todos los posts o solo uno
 */
if ($_SERVER['REQUEST_METHOD'] == 'GET')
{
    if (isset($_GET['id']))
    {
      //Mostrar un post
      $sql = $dbConn->prepare("SELECT * FROM tiendas where id=:id");
      $sql->bindValue(':id', $_GET['id']);
      $sql->execute();
      header("HTTP/1.1 200 OK");
      echo json_encode(  $sql->fetch(PDO::FETCH_ASSOC)  );
      exit();
	  }
    else {
      $query = "SELECT * FROM tiendas";
      //Mostrar lista de post
      if(isset($_GET['productos']))
        $query = "SELECT * FROM productos where idtienda = '".$_GET['idtienda']."'";
      $sql = $dbConn->prepare($query);
      $sql->execute();
      $sql->setFetchMode(PDO::FETCH_ASSOC);
      header("HTTP/1.1 200 OK");
      $result = $sql->fetchAll();
      echo( json_encode(mb_convert_encoding($result, 'UTF-8') ));
        exit();
	}
}

// Crear un nuevo post
if ($_SERVER['REQUEST_METHOD'] == 'POST')
{
  $data = json_encode($_POST);
  $data = json_decode($data);
  $data = json_decode($data->{'pedido'}, true);
  //var_dump($data);
  $sql = "INSERT INTO pedidos (id, usuario, direccion)
        VALUES (UUID(),'" . $data['nombre'] ."','". $data['direccion']."')";
  //echo $sql;
  $statement = $dbConn->prepare($sql);
  $statement->execute();
  $idPedidos = $dbConn->lastInsertId();
  $sql = "SELECT id FROM pedidos where idpk=".$idPedidos;
  $sql = $dbConn->prepare($sql);
  $sql->execute();
  $sql->setFetchMode(PDO::FETCH_ASSOC);
  header("HTTP/1.1 200 OK");
  foreach($sql as $idPedido) {
    $idPedidos = $idPedido['id'];
  }
  $productos = $data['productos'];
  $sql = "";
  foreach($productos as $producto) {
    $sql .= "INSERT INTO pedidoproductos (id, idproducto) VALUES ('".$idPedidos."', '".$producto['id']."');";
  }
  //echo $sql;
  $statement = $dbConn->prepare($sql);
  $statement->execute();
  //echo $sql."\n";
  header("HTTP/1.1 200 OK");
  echo $idPedidos;
  exit();
}

//Borrar
if ($_SERVER['REQUEST_METHOD'] == 'DELETE')
{
  $statement = $dbConn->prepare("DELETE FROM pedidos where id='" . $_GET['id'] . "'");
  $statement->execute();
	header("HTTP/1.1 200 OK");
	exit();
}

//Actualizar
if ($_SERVER['REQUEST_METHOD'] == 'PUT')
{
    $input = $_GET;
    $postId = $input['id'];

    $sql = "
          UPDATE pedidos
          SET pais='". $_GET['pais'] ."'
          WHERE id='".$postId."'";

    $statement = $dbConn->prepare($sql);
    $statement->execute();
    header("HTTP/1.1 200 OK");
    exit();
}


//En caso de que ninguna de las opciones anteriores se haya ejecutado
header("HTTP/1.1 400 Bad Request");

?>
