-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost
-- Tiempo de generación: 25-04-2020 a las 03:01:29
-- Versión del servidor: 10.4.6-MariaDB
-- Versión de PHP: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `dbplaza`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidoproductos`
--

CREATE TABLE `pedidoproductos` (
  `id` varchar(36) COLLATE utf32_spanish_ci NOT NULL,
  `idproducto` varchar(36) COLLATE utf32_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;

--
-- Volcado de datos para la tabla `pedidoproductos`
--

INSERT INTO `pedidoproductos` (`id`, `idproducto`) VALUES
('60ef7b31-82eb-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('60ef7b31-82eb-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('d0418fe2-82eb-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('d0418fe2-82eb-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('c9663506-82ed-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('c9663506-82ed-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('c9663506-82ed-11ea-8e62-f6ffd9adf6b4', 'AA16CAFE-80B7-11EA-BE14-94E979ECB4F6'),
('c9663506-82ed-11ea-8e62-f6ffd9adf6b4', 'ECC35A2B-80B7-11EA-BE14-94E979ECB4F6'),
('c9663506-82ed-11ea-8e62-f6ffd9adf6b4', 'D9BD85B6-80B7-11EA-BE14-94E979ECB4F6'),
('c9663506-82ed-11ea-8e62-f6ffd9adf6b4', 'FC142CCB-80B7-11EA-BE14-94E979ECB4F6'),
('776ebd38-82ee-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('776ebd38-82ee-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('776ebd38-82ee-11ea-8e62-f6ffd9adf6b4', 'AA16CAFE-80B7-11EA-BE14-94E979ECB4F6'),
('9b9b3bfa-82ee-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('9b9b3bfa-82ee-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('9b9b3bfa-82ee-11ea-8e62-f6ffd9adf6b4', 'AA16CAFE-80B7-11EA-BE14-94E979ECB4F6'),
('d8cc3362-82ee-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('d8cc3362-82ee-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('d8cc3362-82ee-11ea-8e62-f6ffd9adf6b4', 'AA16CAFE-80B7-11EA-BE14-94E979ECB4F6'),
('449da2ae-82ef-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('449da2ae-82ef-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('449da2ae-82ef-11ea-8e62-f6ffd9adf6b4', 'AA16CAFE-80B7-11EA-BE14-94E979ECB4F6'),
('73707c9b-82ef-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('73707c9b-82ef-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('73707c9b-82ef-11ea-8e62-f6ffd9adf6b4', 'AA16CAFE-80B7-11EA-BE14-94E979ECB4F6'),
('57a8d6d9-82fb-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('57a8d6d9-82fb-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('ab1e09ca-82fb-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('ab1e09ca-82fb-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('e3add00b-82fb-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('e3add00b-82fb-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('11716db8-82fc-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('11716db8-82fc-11ea-8e62-f6ffd9adf6b4', 'AA16CAFE-80B7-11EA-BE14-94E979ECB4F6'),
('5570e96e-82fc-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('5570e96e-82fc-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('a2d981dd-82fc-11ea-8e62-f6ffd9adf6b4', 'AA16CAFE-80B7-11EA-BE14-94E979ECB4F6'),
('a2d981dd-82fc-11ea-8e62-f6ffd9adf6b4', 'C575B67B-80B7-11EA-BE14-94E979ECB4F6'),
('ae1a68a5-82fc-11ea-8e62-f6ffd9adf6b4', 'AA16CAFE-80B7-11EA-BE14-94E979ECB4F6'),
('ae1a68a5-82fc-11ea-8e62-f6ffd9adf6b4', 'C575B67B-80B7-11EA-BE14-94E979ECB4F6'),
('ceb454ab-82fc-11ea-8e62-f6ffd9adf6b4', 'D9BD85B6-80B7-11EA-BE14-94E979ECB4F6'),
('ceb454ab-82fc-11ea-8e62-f6ffd9adf6b4', 'ECC35A2B-80B7-11EA-BE14-94E979ECB4F6'),
('b1098934-82ff-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('b1098934-82ff-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('f1a94f9f-82ff-11ea-8e62-f6ffd9adf6b4', 'F24CDFF3-80B8-11EA-BE14-94E979ECB4F6'),
('f1a94f9f-82ff-11ea-8e62-f6ffd9adf6b4', 'BB64ADC6-80B8-11EA-BE14-94E979ECB4F6'),
('e20002fb-8308-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('e20002fb-8308-11ea-8e62-f6ffd9adf6b4', 'AA16CAFE-80B7-11EA-BE14-94E979ECB4F6'),
('ff8cf556-8308-11ea-8e62-f6ffd9adf6b4', 'AA68A085-7F97-11EA-A5EA-94E979ECB4F6'),
('0b3a4f00-8309-11ea-8e62-f6ffd9adf6b4', 'AA68A085-7F97-11EA-A5EA-94E979ECB4F6'),
('507e97a6-8309-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('5c56f6fd-8309-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('750f0257-8309-11ea-8e62-f6ffd9adf6b4', 'BB64ADC6-80B8-11EA-BE14-94E979ECB4F6'),
('a7858bad-8309-11ea-8e62-f6ffd9adf6b4', '9A019AD8-80B8-11EA-BE14-94E979ECB4F6'),
('b1540a5d-8309-11ea-8e62-f6ffd9adf6b4', '9A019AD8-80B8-11EA-BE14-94E979ECB4F6'),
('bdd9fab0-8309-11ea-8e62-f6ffd9adf6b4', '9A019AD8-80B8-11EA-BE14-94E979ECB4F6'),
('d72d3d68-8309-11ea-8e62-f6ffd9adf6b4', 'F24CDFF3-80B8-11EA-BE14-94E979ECB4F6'),
('17427b71-830a-11ea-8e62-f6ffd9adf6b4', 'AA68A085-7F97-11EA-A5EA-94E979ECB4F6'),
('175d857b-830a-11ea-8e62-f6ffd9adf6b4', 'AA68A085-7F97-11EA-A5EA-94E979ECB4F6'),
('318207d6-830a-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('7e275e6b-830a-11ea-8e62-f6ffd9adf6b4', '17393C3E-80B7-11EA-BE14-94E979ECB4F6'),
('954af765-830a-11ea-8e62-f6ffd9adf6b4', 'BB64ADC6-80B8-11EA-BE14-94E979ECB4F6'),
('954af765-830a-11ea-8e62-f6ffd9adf6b4', 'F24CDFF3-80B8-11EA-BE14-94E979ECB4F6'),
('c1da36cc-830a-11ea-8e62-f6ffd9adf6b4', 'AA68A085-7F97-11EA-A5EA-94E979ECB4F6'),
('c1da36cc-830a-11ea-8e62-f6ffd9adf6b4', '17393C3E-80B7-11EA-BE14-94E979ECB4F6'),
('fbdfe6e7-830a-11ea-8e62-f6ffd9adf6b4', '17393C3E-80B7-11EA-BE14-94E979ECB4F6'),
('fbdfe6e7-830a-11ea-8e62-f6ffd9adf6b4', '1FC7FDA8-80B7-11EA-BE14-94E979ECB4F6'),
('8306fcf4-830b-11ea-8e62-f6ffd9adf6b4', 'BB64ADC6-80B8-11EA-BE14-94E979ECB4F6'),
('929cc5d2-830b-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('929cc5d2-830b-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('ae9087c4-830b-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('ae9087c4-830b-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('294e6853-830d-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('35e2c3f8-830d-11ea-8e62-f6ffd9adf6b4', 'AA68A085-7F97-11EA-A5EA-94E979ECB4F6'),
('35e2c3f8-830d-11ea-8e62-f6ffd9adf6b4', '17393C3E-80B7-11EA-BE14-94E979ECB4F6'),
('7aa14199-830d-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('b017e864-830d-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('bc826a05-830d-11ea-8e62-f6ffd9adf6b4', 'AA68A085-7F97-11EA-A5EA-94E979ECB4F6'),
('bc826a05-830d-11ea-8e62-f6ffd9adf6b4', '17393C3E-80B7-11EA-BE14-94E979ECB4F6'),
('0b6cc715-830e-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('1625fabc-830e-11ea-8e62-f6ffd9adf6b4', 'BB64ADC6-80B8-11EA-BE14-94E979ECB4F6'),
('1625fabc-830e-11ea-8e62-f6ffd9adf6b4', 'F24CDFF3-80B8-11EA-BE14-94E979ECB4F6'),
('697bbba0-830e-11ea-8e62-f6ffd9adf6b4', 'AA68A085-7F97-11EA-A5EA-94E979ECB4F6'),
('697bbba0-830e-11ea-8e62-f6ffd9adf6b4', '17393C3E-80B7-11EA-BE14-94E979ECB4F6'),
('8e7695ec-8310-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('8e7695ec-8310-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('9a3bcd3d-8310-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('9a3bcd3d-8310-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('807fc5f3-8312-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('79dc3f6c-8314-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('c1c2d61b-8314-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('d90dc7fc-8314-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('d90dc7fc-8314-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('344d495b-8315-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('559ca0ba-831b-11ea-8e62-f6ffd9adf6b4', 'AA68A085-7F97-11EA-A5EA-94E979ECB4F6'),
('559ca0ba-831b-11ea-8e62-f6ffd9adf6b4', '17393C3E-80B7-11EA-BE14-94E979ECB4F6'),
('5ff3c934-831b-11ea-8e62-f6ffd9adf6b4', '9A019AD8-80B8-11EA-BE14-94E979ECB4F6'),
('060fbf00-8320-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('ad898c97-8320-11ea-8e62-f6ffd9adf6b4', '26B6A9DB-7F4B-11EA-A5EA-94E979ECB4F6'),
('ad898c97-8320-11ea-8e62-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('6a656352-85cd-11ea-9783-f6ffd9adf6b4', '95D1AE29-80B7-11EA-BE14-94E979ECB4F6'),
('742ec6fd-85cd-11ea-9783-f6ffd9adf6b4', 'AA68A085-7F97-11EA-A5EA-94E979ECB4F6');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `idpk` int(11) NOT NULL,
  `id` varchar(36) COLLATE utf32_spanish_ci NOT NULL,
  `usuario` varchar(100) COLLATE utf32_spanish_ci NOT NULL,
  `direccion` varchar(100) COLLATE utf32_spanish_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`idpk`, `id`, `usuario`, `direccion`) VALUES
(91, '60ef7b31-82eb-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Junco'),
(92, 'd0418fe2-82eb-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Junco'),
(93, 'c9663506-82ed-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Junco'),
(94, '776ebd38-82ee-11ea-8e62-f6ffd9adf6b4', '', ''),
(95, '9b9b3bfa-82ee-11ea-8e62-f6ffd9adf6b4', '', ''),
(96, 'd8cc3362-82ee-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Junco'),
(97, '449da2ae-82ef-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Junco'),
(98, '73707c9b-82ef-11ea-8e62-f6ffd9adf6b4', '', ''),
(99, '57a8d6d9-82fb-11ea-8e62-f6ffd9adf6b4', 'Paulina', 'Junco'),
(100, 'ab1e09ca-82fb-11ea-8e62-f6ffd9adf6b4', '', ''),
(101, 'e3add00b-82fb-11ea-8e62-f6ffd9adf6b4', 'Paulina', 'Junco'),
(102, '11716db8-82fc-11ea-8e62-f6ffd9adf6b4', '', ''),
(103, '5570e96e-82fc-11ea-8e62-f6ffd9adf6b4', 'Paulina', 'Junco'),
(104, 'a2d981dd-82fc-11ea-8e62-f6ffd9adf6b4', 'Paulina', 'Revolucio'),
(105, 'ae1a68a5-82fc-11ea-8e62-f6ffd9adf6b4', 'Paulina', 'Revolucio'),
(106, 'ceb454ab-82fc-11ea-8e62-f6ffd9adf6b4', 'Paulina', 'Calle'),
(107, 'b1098934-82ff-11ea-8e62-f6ffd9adf6b4', '1', '2'),
(108, 'f1a94f9f-82ff-11ea-8e62-f6ffd9adf6b4', '2', '2'),
(109, 'e20002fb-8308-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Junco'),
(110, 'ff8cf556-8308-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Junco'),
(111, '0b3a4f00-8309-11ea-8e62-f6ffd9adf6b4', 'Paulina', 'Junco'),
(112, '507e97a6-8309-11ea-8e62-f6ffd9adf6b4', 'Paulina', 'Junco'),
(113, '5c56f6fd-8309-11ea-8e62-f6ffd9adf6b4', 'Juan', 'Junco'),
(114, '750f0257-8309-11ea-8e62-f6ffd9adf6b4', 'Pedro', 'Junco'),
(115, 'a7858bad-8309-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Junco'),
(116, 'b1540a5d-8309-11ea-8e62-f6ffd9adf6b4', 'Juan', 'Junco'),
(117, 'bdd9fab0-8309-11ea-8e62-f6ffd9adf6b4', 'Javier', 'Junco'),
(118, 'd72d3d68-8309-11ea-8e62-f6ffd9adf6b4', 'Javier antonio', 'Junco'),
(119, '17427b71-830a-11ea-8e62-f6ffd9adf6b4', 'Juan', 'Pedro'),
(120, '175d857b-830a-11ea-8e62-f6ffd9adf6b4', 'Juan', 'Pedro'),
(121, '318207d6-830a-11ea-8e62-f6ffd9adf6b4', 'Paulina', 'Pedro'),
(122, '7e275e6b-830a-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Junco'),
(123, '954af765-830a-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Junco'),
(124, 'c1da36cc-830a-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Junco'),
(125, 'fbdfe6e7-830a-11ea-8e62-f6ffd9adf6b4', 'Pau', 'Junco'),
(126, '8306fcf4-830b-11ea-8e62-f6ffd9adf6b4', 'Pedro', 'Junco'),
(127, '929cc5d2-830b-11ea-8e62-f6ffd9adf6b4', 'Pedro', 'Junco'),
(128, 'ae9087c4-830b-11ea-8e62-f6ffd9adf6b4', 'Alex', 'Junco'),
(129, '294e6853-830d-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Junco'),
(130, '35e2c3f8-830d-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Junco'),
(131, '7aa14199-830d-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Junco'),
(132, 'b017e864-830d-11ea-8e62-f6ffd9adf6b4', 'Prueba', 'Junco'),
(133, 'bc826a05-830d-11ea-8e62-f6ffd9adf6b4', 'Prueba', 'Junco'),
(134, '0b6cc715-830e-11ea-8e62-f6ffd9adf6b4', 'Alex', 'Junco'),
(135, '1625fabc-830e-11ea-8e62-f6ffd9adf6b4', 'Ruben', 'Junco'),
(136, '697bbba0-830e-11ea-8e62-f6ffd9adf6b4', 'Juan', 'Junco'),
(137, '8e7695ec-8310-11ea-8e62-f6ffd9adf6b4', 'Juan', 'Pedro'),
(138, '9a3bcd3d-8310-11ea-8e62-f6ffd9adf6b4', 'Juan', 'Pedro'),
(139, '807fc5f3-8312-11ea-8e62-f6ffd9adf6b4', 'Nombre', 'Dir'),
(140, '79dc3f6c-8314-11ea-8e62-f6ffd9adf6b4', '3', '3'),
(141, 'c1c2d61b-8314-11ea-8e62-f6ffd9adf6b4', '1', '1'),
(142, 'd90dc7fc-8314-11ea-8e62-f6ffd9adf6b4', '3', '3'),
(143, '344d495b-8315-11ea-8e62-f6ffd9adf6b4', '2', '2'),
(144, '559ca0ba-831b-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Correos'),
(145, '5ff3c934-831b-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Correos'),
(146, '060fbf00-8320-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Sta julia'),
(147, 'ad898c97-8320-11ea-8e62-f6ffd9adf6b4', 'Ramon', 'Sta Julia'),
(148, '6a656352-85cd-11ea-9783-f6ffd9adf6b4', 'Ramon', 'Quinta de Allende #116'),
(149, '742ec6fd-85cd-11ea-9783-f6ffd9adf6b4', 'Ramon', 'Quinta de Allende #116');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id` varchar(36) COLLATE utf32_spanish_ci NOT NULL,
  `idtienda` varchar(36) COLLATE utf32_spanish_ci NOT NULL,
  `nombre` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `descripcion` varchar(100) COLLATE utf32_spanish_ci NOT NULL,
  `thumbnail` varchar(200) COLLATE utf32_spanish_ci DEFAULT NULL,
  `costo` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id`, `idtienda`, `nombre`, `descripcion`, `thumbnail`, `costo`) VALUES
('26b6a9db-7f4b-11ea-a5ea-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Jitomate', 'un kilo de jitomate', 'https://ep01.epimg.net/verne/imagenes/2019/05/16/mexico/1557976662_364527_1557978084_noticia_normal.jpg', 26),
('95d1ae29-80b7-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Kilo de cebolla', 'Kilo fresco de cebolla', 'https://ep01.epimg.net/elpais/imagenes/2020/02/17/buenavida/1581937848_519078_1581938419_noticia_normal.jpg', 18.34),
('aa16cafe-80b7-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Galletas saladas', 'paquete de galletas saladas', 'https://tienda.scorpion.com.mx/media/catalog/product/cache/e4d64343b1bc593f1c5348fe05efa4a6/8/5/8522.jpg', 15),
('c575b67b-80b7-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Pan Blanco', 'Pan blanco bimbo', 'https://www.superama.com.mx/Content/images/products/img_large/0750100011120L.jpg', 40),
('d9bd85b6-80b7-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Madalenas', 'Pan dulce bimbo', 'https://cdn.shopify.com/s/files/1/0706/6309/products/000122995-3m_300x300.jpg', 13.5),
('ecc35a2b-80b7-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Aceite para cocina', 'Aceite para cocinar', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00750103912248L.jpg', 29.7),
('fc142ccb-80b7-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Kilo de sal de mesa', 'un kilo de sal de mesa yodatada', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00003458702002L.jpg', 9.8),
('15484779-80b8-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Jabon para Mano', 'Jabon para lavarse las mano', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00750626790800L.jpg', 56),
('318debb5-80b8-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Jabon de Rop', 'Jabon para Ropa', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00750119941885L.jpg', 120),
('4fe0661b-80b8-11ea-be14-94e979ecb4f6', 'b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Suavizante', 'Suavizante para Ropa ', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00750954607544L.jpg', 110),
('aa68a085-7f97-11ea-a5ea-94e979ecb4f6', 'ecd2ddcd-7f96-11ea-a5ea-94e979ecb4f6', 'Kilo de Bistec', 'Kilo fresco de bistec de bola', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00020137000000L.jpg', 128),
('17393c3e-80b7-11ea-be14-94e979ecb4f6', 'ecd2ddcd-7f96-11ea-a5ea-94e979ecb4f6', 'Kilo de Molida de res', 'Kilo fresco de molida de res', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00020123300000L.jpg', 140),
('1fc7fda8-80b7-11ea-be14-94e979ecb4f6', 'ecd2ddcd-7f96-11ea-a5ea-94e979ecb4f6', 'Kilo de chorizo', 'Kilo fresco de chorizo', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00020165000000L.jpg', 70),
('276d0503-80b7-11ea-be14-94e979ecb4f6', 'ecd2ddcd-7f96-11ea-a5ea-94e979ecb4f6', 'Kilo de cocido de res', 'Kilo fresco de cocido de res', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00750179166934L.jpg', 89),
('2e331d63-80b7-11ea-be14-94e979ecb4f6', 'ecd2ddcd-7f96-11ea-a5ea-94e979ecb4f6', 'Kilo de chuleta de cerdo', 'Kilo de chuleta de cerdo', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00020101000000L.jpg', 84),
('9a019ad8-80b8-11ea-be14-94e979ecb4f6', '60419a23-7f97-11ea-a5ea-94e979ecb4f6', 'Promocion', 'Medio pollo rostizado con arroz y tortillas con el sabor de casa', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00020912300000L.jpg', 59),
('bb64adc6-80b8-11ea-be14-94e979ecb4f6', '2760d80c-7f97-11ea-a5ea-94e979ecb4f6', 'Pollo', 'Un pollo rostizado con el sabor de casa y sazon que ya conoce', 'https://res.cloudinary.com/walmart-labs/image/upload/w_960,dpr_auto,f_auto,q_auto:best/gr/images/product-images/img_large/00020903200000L.jpg', 90),
('f24cdff3-80b8-11ea-be14-94e979ecb4f6', '2760d80c-7f97-11ea-a5ea-94e979ecb4f6', 'Sopa de arroz', 'Una porcion de deliciosa sopa de arroz', 'https://d1uz88p17r663j.cloudfront.net/original/F4547176-811C-6377-B9D8-FF0000673B69-610x360-b-min.png', 13),
('0df2aec4-80b9-11ea-be14-94e979ecb4f6', '2760d80c-7f97-11ea-a5ea-94e979ecb4f6', 'Pierna de Pavo', 'Deliciosa pierna de Pavo rostizada ', 'https://esperanza.tr3sco.net/Content/_files/images/product/productos-calientes-4-0855322744164301.png', 56.5),
('2a180060-80b9-11ea-be14-94e979ecb4f6', '2760d80c-7f97-11ea-a5ea-94e979ecb4f6', 'Medio pollo', 'Mitad de sabroso pollo', 'https://t2.rg.ltmcdn.com/es/images/9/7/0/pollo_asado_al_horno_56079_orig.jpg', 38.9);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tiendas`
--

CREATE TABLE `tiendas` (
  `id` varchar(36) COLLATE utf32_spanish_ci NOT NULL,
  `nombre` varchar(50) COLLATE utf32_spanish_ci NOT NULL,
  `descripcion` varchar(100) COLLATE utf32_spanish_ci NOT NULL,
  `telefono` varchar(100) COLLATE utf32_spanish_ci NOT NULL,
  `ubicacion` varchar(100) COLLATE utf32_spanish_ci NOT NULL,
  `imagen` varchar(200) COLLATE utf32_spanish_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf32 COLLATE=utf32_spanish_ci;

--
-- Volcado de datos para la tabla `tiendas`
--

INSERT INTO `tiendas` (`id`, `nombre`, `descripcion`, `telefono`, `ubicacion`, `imagen`) VALUES
('b4b2a879-7ebf-11ea-b2e7-94e979ecb4f6', 'Las quince letras', 'Venta de Abarrotes', '4578784512', 'Colonia laureles, torreslanda #27', 'https://definicion.de/wp-content/uploads/2015/05/abarrotes.jpg'),
('ecd2ddcd-7f96-11ea-a5ea-94e979ecb4f6', 'Carniceria Mi Esperanza', 'La carne mas fresca de la region ', '4611014583', 'CALLE GALAXIA, #146, COLONIA ZONA DE ORO I', 'https://destinonegocio.com/wp-content/uploads/2015/12/ico-destinonegocio-carniceria-istock-getty-images-1030x767.jpg'),
('2760d80c-7f97-11ea-a5ea-94e979ecb4f6', 'Pollos hermanos', 'Pollo estilo Sinaloa', '4611099310', 'Limonero 531, Girasoles, 38020 Celaya, Gto.', 'https://elmercurio.com.mx/wp-content/uploads/bfi_thumb/1-18-6jpo8gyg0294uammhvo5it5e4txrxz9z9b067l2t4mo.jpeg'),
('60419a23-7f97-11ea-a5ea-94e979ecb4f6', 'Rosticeria La Estrella', 'Rosticeria La Estrella', '4421584897', 'Quetzalli 503, Alamos, 38024 Celaya, Gto.', 'https://image.freepik.com/vector-gratis/ilustracion-mascota-pollo-parrilla_1594-82.jpg');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`idpk`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `idpk` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=150;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
